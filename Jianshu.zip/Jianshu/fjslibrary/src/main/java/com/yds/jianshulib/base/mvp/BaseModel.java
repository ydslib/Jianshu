package com.yds.jianshu.base.mvp;

/**
 * Created by yds
 * on 2019/8/29.
 */
public abstract class BaseModel {

}
