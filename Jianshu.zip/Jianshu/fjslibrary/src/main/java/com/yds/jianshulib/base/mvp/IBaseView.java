package com.yds.jianshu.base.mvp;

import android.content.Context;

/**
 * Created by yds
 * on 2019/8/3.
 */
public interface IBaseView {
    Context getContext();
}
