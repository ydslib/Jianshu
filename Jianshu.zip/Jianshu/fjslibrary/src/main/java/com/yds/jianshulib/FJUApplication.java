package com.yds.jianshu;

import android.app.Application;

/**
 * Created by yds
 * on 2019/8/13.
 */
public class FJUApplication extends Application {
}
