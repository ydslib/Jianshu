package com.yds.jianshu.itf;

/**
 * Created by yds
 * on 2019/8/2.
 */
public interface Manager {
    //预留接口
}
