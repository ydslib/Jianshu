package com.yds.jianshu;

import android.app.Application;

/**
 * Created by yds
 * on 2019/8/3.
 */
public class FakeJUApplication extends Application {
    public FakeJUApplication(){

    }

    @Override
    public void onCreate() {
        super.onCreate();
    }
}
