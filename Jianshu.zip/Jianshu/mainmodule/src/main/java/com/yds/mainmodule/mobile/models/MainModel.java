package com.yds.mainmodule.mobile.models;

import com.yds.jianshu.base.mvp.BaseModel;
import com.yds.mainmodule.mobile.contract.MainContract;

/**
 * Created by yds
 * on 2019/8/29.
 */
public class MainModel extends BaseModel implements MainContract.IMainModel {
}
