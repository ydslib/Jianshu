package com.yds.mainmodule;

import android.app.Application;

/**
 * Created by yds
 * on 2019/8/13.
 */
public class MainApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();

    }
}
