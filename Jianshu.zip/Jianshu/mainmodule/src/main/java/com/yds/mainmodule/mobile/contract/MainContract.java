package com.yds.mainmodule.mobile.contract;

import com.yds.jianshu.base.mvp.IBasePresenter;
import com.yds.jianshu.base.mvp.IBaseView;

/**
 * Created by yds
 * on 2019/8/29.
 */
public interface MainContract {
    interface IMainModel{

    }
    interface IMainView extends IBaseView{

    }
    interface IMainPresenter extends IBasePresenter{

    }
}
